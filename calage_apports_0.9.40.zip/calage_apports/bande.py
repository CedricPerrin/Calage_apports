"""Bande verticale des étapes, commune aux extensions de la maison (décision de l'ingénieur du
23/10/2026 : « format commun du menu à gauche », la bande de Rhoé ; étendue le même jour aux
autres extensions).

Chaque extension qui l'emploie en garde une copie identique (liste : ``D:\\1-Dev\\CLAUDE.md``,
« Coordination entre plugins ») : changer l'une, c'est changer toutes.
"""

from __future__ import annotations

import math

from qgis.PyQt.QtCore import QModelIndex, QRectF, QSize, Qt
from qgis.PyQt.QtGui import QFont, QFontMetricsF, QPainter, QPalette, QResizeEvent
from qgis.PyQt.QtWidgets import (
    QApplication,
    QListWidget,
    QProxyStyle,
    QStyle,
    QStyledItemDelegate,
    QStyleOptionViewItem,
)


class Bande(QListWidget):
    """Bande des étapes dont le bas n'est jamais coupé (retour de l'utilisateur du 11 octobre
    2026) : numéro et nom de chaque étape quand la hauteur les contient tous ; sinon le numéro
    seul ; si la place manque encore (écran bas, échelle 150 %), la bande défile. Le numéro est
    en gras (demande du 23/10/2026 : « pour mieux différencier les menus »).

    Une entrée non sélectionnable est un intitulé de groupe (:class:`NumeroGras`), le même
    texte dans ``complets`` et ``courts``. Sans l'indicateur « activé » non plus
    (``Qt.ItemFlag.NoItemFlags``), ni la souris ni les flèches du clavier ne s'y arrêtent."""

    def __init__(self, complets: list[str], courts: list[str], largeur: int, ligne: int) -> None:
        super().__init__()
        self._textes = (complets, courts)
        self._largeur = largeur
        self._ligne = ligne
        #: Hauteur d'une étape réduite à son numéro, en px.
        self.hauteur_courte = int(ligne * 1.4)
        self._complete: bool | None = None
        self.setItemDelegate(NumeroGras(self))

    @property
    def hauteur_complete(self) -> int:
        """Hauteur de toutes les étapes avec leur nom, cadre compris, en px."""
        return sum(self._hauteurs(self._textes[0])) + 2 * self.frameWidth()

    def _hauteurs(self, textes: list[str]) -> list[int]:
        """Hauteur de chaque entrée de ``textes`` : ses lignes, plus 0,4 ligne. Un intitulé de
        groupe compte ses lignes dans :func:`police_intitule`, plus haute de 15 % : comptées dans
        la petite police, quatre lignes débordaient de leur case (Hyétos 0.6.0, 28/10/2026)."""
        pas = QFontMetricsF(police_intitule(self.font())).lineSpacing()
        hauteurs = []
        for rang, texte in enumerate(textes):
            lignes = texte.count("\n") + 1
            element = self.item(rang)
            if element is not None and not element.flags() & Qt.ItemFlag.ItemIsSelectable:
                hauteurs.append(math.ceil(lignes * pas + 0.4 * self._ligne))
            else:
                hauteurs.append(int(self._ligne * (lignes + 0.4)))
        return hauteurs

    def resizeEvent(self, evenement: QResizeEvent) -> None:  # noqa: N802 — API Qt
        """Choisit la forme des étapes à chaque changement de hauteur."""
        super().resizeEvent(evenement)
        self.ajuster(evenement.size().height())

    def ajuster(self, hauteur: int) -> None:
        """Numéro et nom si ``hauteur`` (px, cadre compris) les contient, numéro seul sinon. Un
        intitulé de groupe garde la hauteur de ses lignes : réduit à 1,4 ligne, « Analyse / de la /
        station » chevauchait les numéros voisins (recette CPN du 24/11/2026, P5)."""
        complete = hauteur >= self.hauteur_complete
        if complete == self._complete:
            return
        self._complete = complete
        textes = self._textes[0 if complete else 1]
        hauteurs = self._hauteurs(textes)
        for rang in range(self.count()):
            element = self.item(rang)
            element.setText(textes[rang])
            groupe = not element.flags() & Qt.ItemFlag.ItemIsSelectable
            haut = hauteurs[rang] if complete or groupe else self.hauteur_courte
            element.setSizeHint(QSize(self._largeur, haut))


class NumeroGras(QStyledItemDelegate):
    """Dessine une étape : sa première ligne (le numéro) en gras, le reste (le nom) dessous en
    police normale, centrés ; fond, sélection et focus restent ceux du style de l'hôte. Une entrée
    non sélectionnable est un intitulé de groupe : un filet au-dessus, son texte en petit, sans
    fond alterné."""

    def paint(self, peintre: QPainter, option: QStyleOptionViewItem, index: QModelIndex) -> None:
        """Le fond par le style, puis le texte en deux polices."""
        vue = QStyleOptionViewItem(option)
        self.initStyleOption(vue, index)
        texte, vue.text = vue.text, ""
        if not index.flags() & Qt.ItemFlag.ItemIsSelectable:
            self._intitule(peintre, vue, texte)
            return
        style = vue.widget.style() if vue.widget else QApplication.style()
        style.drawControl(QStyle.ControlElement.CE_ItemViewItem, vue, peintre, vue.widget)
        if vue.state & QStyle.StateFlag.State_Selected:
            # Repère de l'étape courante, comme la navigation de Windows 11 : sans le focus, le
            # style natif la peint d'un gris que les lignes alternées ont aussi (27/10/2026).
            repere = QRectF(vue.rect.left() + 1, vue.rect.top() + 4, 3, vue.rect.height() - 8)
            accent = vue.palette.color(QPalette.ColorGroup.Active, QPalette.ColorRole.Highlight)
            peintre.fillRect(repere, accent)
        # Les styles natifs de Windows peignent la sélection en clair et y écrivent le texte
        # ordinaire : leur « texte surligné » blanc s'y lirait mal (style de QGIS sous Windows,
        # enveloppé par QGIS dans un style mandataire ; constat du 23/10/2026).
        base = style.baseStyle() if isinstance(style, QProxyStyle) else style
        natif = base.metaObject().className() in ("QWindowsVistaStyle", "QWindows11Style")
        choisi = bool(vue.state & QStyle.StateFlag.State_Selected) and not natif
        role = QPalette.ColorRole.HighlightedText if choisi else QPalette.ColorRole.Text
        # Le groupe de couleurs de l'état, comme le style : fenêtre inactive, sélection grise.
        groupe = (
            QPalette.ColorGroup.Disabled
            if not vue.state & QStyle.StateFlag.State_Enabled
            else QPalette.ColorGroup.Active
            if vue.state & QStyle.StateFlag.State_Active
            else QPalette.ColorGroup.Inactive
        )
        numero, *noms = _lignes(texte)
        gras = QFont(vue.font)
        gras.setBold(True)
        peintre.save()
        peintre.setPen(vue.palette.color(groupe, role))
        _poser(peintre, QRectF(vue.rect), [(gras, numero)] + [(vue.font, nom) for nom in noms])
        peintre.restore()

    @staticmethod
    def _intitule(peintre: QPainter, vue: QStyleOptionViewItem, texte: str) -> None:
        """Intitulé de groupe : filet en haut, texte en :func:`police_intitule` au centre, dans la
        couleur du texte actif (une entrée désactivée prendrait le gris de la palette, trop pâle
        pour se lire)."""
        peintre.save()
        peintre.setPen(vue.palette.color(QPalette.ColorRole.Mid))
        haut = vue.rect.top() + 1
        peintre.drawLine(vue.rect.left() + 3, haut, vue.rect.right() - 3, haut)
        actif = QPalette.ColorGroup.Active
        peintre.setPen(vue.palette.color(actif, QPalette.ColorRole.Text))
        police = police_intitule(vue.font)
        _poser(peintre, QRectF(vue.rect), [(police, ligne) for ligne in _lignes(texte)])
        peintre.restore()


def _lignes(texte: str) -> list[str]:
    """Les lignes du texte d'une entrée (``initStyleOption`` change les sauts de ligne en
    séparateurs de ligne Unicode)."""
    return texte.replace("\u2028", "\n").split("\n")


def _poser(peintre: QPainter, case: QRectF, lignes: list[tuple[QFont, str]]) -> None:
    """Pose les ``lignes`` (police, texte) au centre de ``case``, une à une, au pas de la dernière
    police, sans les couper (QGIS 3.44.14 à 150 %, 29/10/2026 : le « g » de « Hydro- / grammes »
    était rogné). ``drawText`` coupe à son cadre un texte de plusieurs lignes qui le dépasse, et
    une ligne close par un saut y prend la hauteur d'une police de secours : 13 px au lieu de
    12,06 en MS Shell Dlg 2 à 7,47 pt. Posée seule, une ligne ne prend que la sienne."""
    pas = QFontMetricsF(lignes[-1][0]).lineSpacing()
    y = case.top() + (case.height() - pas * len(lignes)) / 2
    # ``value`` : sous PyQt6, un drapeau Qt n'est plus un entier (``int()`` lève TypeError).
    drapeaux = (Qt.AlignmentFlag.AlignHCenter, Qt.AlignmentFlag.AlignTop, Qt.TextFlag.TextDontClip)
    centre = sum(int(getattr(drapeau, "value", drapeau)) for drapeau in drapeaux)
    for rang, (police, ligne) in enumerate(lignes):
        peintre.setFont(police)
        peintre.drawText(QRectF(case.left(), y + rang * pas, case.width(), pas), centre, ligne)


def police_intitule(police: QFont) -> QFont:
    """Police d'un intitulé de groupe : celle de la bande, en gras, agrandie de 15 % (demande du
    23/10/2026 : les intitulés « ne sont pas lisibles en l'état » à 85 %, sans gras). L'hôte
    mesure ses intitulés dans cette police pour régler la largeur de la bande."""
    grande = QFont(police)
    if grande.pointSizeF() > 0:
        grande.setPointSizeF(grande.pointSizeF() * 1.15)
    grande.setBold(True)
    return grande
